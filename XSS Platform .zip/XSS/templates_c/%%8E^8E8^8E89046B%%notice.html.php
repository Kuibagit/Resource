<?php /* Smarty version 2.6.26, created on 2014-07-04 18:16:08
         compiled from notice.html */ ?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title><?php echo $this->_tpl_vars['notice']['str']; ?>
</title>
<link rel="stylesheet" href="<?php echo $this->_tpl_vars['url']['themePath']; ?>
/css/style/screen.css" type="text/css">
<link rel="stylesheet" href="<?php echo $this->_tpl_vars['url']['themePath']; ?>
/css/style/print.css" type="text/css">
<!--[if lt IE 8]><link rel="stylesheet" href="<?php echo $this->_tpl_vars['url']['themePath']; ?>
/style/ie.css" type="text/css"><![endif]-->
<link rel="stylesheet" href="<?php echo $this->_tpl_vars['url']['themePath']; ?>
/css/style/style.css" type="text/css">
<script type="text/javascript">
setTimeout("location.href='<?php echo $this->_tpl_vars['notice']['turnto']; ?>
'",500);
</script>
</head>
<body>
<div class="container">
	<div style="margin:50px auto 0 auto" class="<?php echo $this->_tpl_vars['notice']['style']; ?>
"><?php echo $this->_tpl_vars['notice']['str']; ?>
 <a href="<?php echo $this->_tpl_vars['notice']['turnto']; ?>
"><?php echo $this->_tpl_vars['notice']['urltitle']; ?>
</a></div>
</div>
</body>
</html>